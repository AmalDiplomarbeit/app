var fs = require("fs");
var express = require("express");

var bmws = JSON.parse(fs.readFileSync("./../model/autos.json"));


function getBMWS(){
    return bmws;
}

function waehleMarke(id,callback){
    for(var i = 0;i<bmws.length;i++){
        if(bmws[i].id == id){
            if(bmws[i].selected == true){
                bmws[i].selected = false;
            }
            else {
                bmws[i].selected = true;
            }
        }
    }
    var selectedbmws = [];
    for(var i = 0;i<bmws.length;i++){
        if(bmws[i].selected == true){
            selectedbmws.push(bmws[i]);
        }
    }
    callback(null,selectedbmws);
}

module.exports = {
    getBMWS,
    waehleMarke
};