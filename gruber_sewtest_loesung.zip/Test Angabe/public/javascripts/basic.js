/**
 * Created by swpr on 24.03.2017.
 */


$('.shoppingcart').hide();
var selectedbmws = [];

function waehleMarke(id){
    console.log(id);
    $.ajax({
        type: "PUT",
        url: "/" + id,
        success: function(result){
            selectedbmws = result;
            for(var i = 0;i<selectedbmws.length;i++){
                console.log("Länge:" + selectedbmws.length);
                if(selectedbmws[i].id == id){
                    console.log("selectiert");
                    if(selectedbmws[i].selected == true){
                        console.log("anzeigen");
                        $('#cart'+id).show();
                        break;
                    }
                }
                else{
                    console.log("bug");
                    $('#cart'+id).hide();
                }
            }
            if(selectedbmws.length == 0){
                $('#cart'+id).hide();
            };

        },
        error: function(err){
            console.log(err);
        }
    })
}

function showSelected(){
    $('.liselected').remove();
    for(var i = 0;i<selectedbmws.length;i++){
        $('#shoppingcartbutton').after(`<li class="liselected">${selectedbmws[i].marke}</li>`);
    }
}
