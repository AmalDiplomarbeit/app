var express = require('express');
var router = express.Router();
var datamodel = require('../model/data');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { bmws: datamodel.getBMWS() });
});
router.put('/:id', function(req,res,next){
  datamodel.waehleMarke(req.params.id, (err,result)=>{
    if(err){
      res.status(500).send(err);
    }
    if(result){
      res.send(result);
    }
  });
});

module.exports = router;
